/* -*-	Mode:C++; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */
/*
 * Copyright (c) 1990, 1997 Regents of the University of California.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms are permitted
 * provided that the above copyright notice and this paragraph are
 * duplicated in all such forms and that any documentation,
 * advertising materials, and other materials related to such
 * distribution and use acknowledge that the software was developed
 * by the University of California, Lawrence Berkeley Laboratory,
 * Berkeley, CA.  The name of the University may not be used to
 * endorse or promote products derived from this software without
 * specific prior written permission.
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND WITHOUT ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED
 * WARRANTIES OF MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 */

#ifndef lint
static const char rcsid[] =
    "@(#) $Header: /cvsroot/nsnam/ns-2/tcp/tcp-reno.cc,v 1.43 2006/06/14 18:05:30 sallyfloyd Exp $ (LBL)";
#endif

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>

#include "ip.h"
#include "tcp.h"
#include "flags.h"


//To trace this module
#include "../mac/docsis/docsisDebug.h"
//#define TCPRENO 0
#define  TRACED_CX 501

//if 1, then ignore loss
#define HIGHSPEED 0 


//To have the tcpRTT trace retrans, do this .  Else it traces dups...
#define TRACERETRANS 0

//Used to trace the tcp cx associated with a given web sessionID (see webtraf.cc)
//#define TRACE_THROUGHPUT 0
//#define TRACED_THROUGHPUT_CX 1000

//RCS 2
//To trace a burst , see expoo.cc for the start
#define TRACEBURST 0
//TRACEBURST needs this to be right....this is for the WRT monitor
//This dis also the cx that will be traced with printfs if TCPRENO is defined
#define TRACED_BURST_CX 1



static class RenoTcpClass : public TclClass {
public:
	RenoTcpClass() : TclClass("Agent/TCP/Reno") {}
	TclObject* create(int, const char*const*) {
		return (new RenoTcpAgent());
	}
} class_reno;

int RenoTcpAgent::window()
{
	//
	// reno: inflate the window by dupwnd_
	//	dupwnd_ will be non-zero during fast recovery,
	//	at which time it contains the number of dup acks
	//
	int win = int(cwnd_) + dupwnd_;
	if (frto_ == 2) {
		// First ack after RTO has arrived.
		// Open window to allow two new segments out with F-RTO.
		win = force_wnd(2);
	}
	if (win > int(wnd_))
		win = int(wnd_);
	return (win);
}

double RenoTcpAgent::windowd()
{
	//
	// reno: inflate the window by dupwnd_
	//	dupwnd_ will be non-zero during fast recovery,
	//	at which time it contains the number of dup acks
	//
	double win = cwnd_ + dupwnd_;
	if (win > wnd_)
		win = wnd_;
	return (win);
}

RenoTcpAgent::RenoTcpAgent() : TcpAgent(), dupwnd_(0)
{
}

void RenoTcpAgent::recv(Packet *pkt, Handler*)
{
	hdr_tcp *tcph = hdr_tcp::access(pkt);
	int valid_ack = 0;
        if (qs_approved_ == 1 && tcph->seqno() > last_ack_)
		endQuickStart();
        if (qs_requested_ == 1)
                processQuickStart(pkt);
#ifdef notdef
	if (pkt->type_ != PT_ACK) {
		fprintf(stderr,
			"ns: configuration error: tcp received non-ack\n");
		exit(1);
	}
#endif
        /* W.N.: check if this is from a previous incarnation */
        if (tcph->ts() < lastreset_) {
                // Remove packet and do nothing
                Packet::free(pkt);
                return;
        }

//$A302
        int bytes = hdr_cmn::access(pkt)->size();

	++nackpack_;
	ts_peer_ = tcph->ts();

	if (hdr_flags::access(pkt)->ecnecho() && ecn_)
		ecn(tcph->seqno());
	recv_helper(pkt);
	recv_frto_helper(pkt);

//$A304
//#ifdef TRACEACK
#ifdef SENDSIDESNUMACKTRACE 
  if (cx_id_ == SNUMACKTRACED_CX )
    FILE* fp = fopen("snumack.out", "a+");
    fprintf(fp,"2 %6.6f %d \n", Scheduler::instance().clock(),((tcph->seqno()+1)*size_ +1));
    fclose(fp);
  }
  if (cx_id_ == SNUMACKTRACED2_CX )
    FILE* fp = fopen("snumack2.out", "a+");
    fprintf(fp,"2 %6.6f %d \n", Scheduler::instance().clock(),((tcph->seqno()+1)*size_ +1));
    fclose(fp);
  }
#endif



	if (tcph->seqno() > last_ack_) {


//$A304
#ifdef TCPRENO
      if (cx_id_ == TRACED_CX)
        printf("TCPReno:recv(%g): seqno ( %d) larger than last_ack (%d), nextTimedSeqno:%d\n",
           Scheduler::instance().clock(), tcph->seqno(), last_ack_,nextTimedSeqno);
#endif



		if (last_cwnd_action_ == CWND_ACTION_DUPACK)
			last_cwnd_action_ = CWND_ACTION_EXITED;
		dupwnd_ = 0;
		recv_newack_helper(pkt);
		if (last_ack_ == 0 && delay_growth_) {
			cwnd_ = initial_window();
		}



//$A304
// Got a new ack,  let's get a tcpRTT sample but
// only if the just received ack is > highest_ack_ AND if
//         the seqno is greater than the maxseq_
//   NOTE: the tcph->ts() contains the time the receiver
//         received the packet (his time is sync to system time)
//  nextTimedSeqno is nonzero when we find a dup ack.  We don't want
//  to use anymore rtt samples until the retransmitted pkt is ack'ed...
// The effect here is to try to time every pkt sent.  However, we only
// obtain a RTT sample for the snum corresponding to the actual snum
// being acked.  If the ack ack's more than 1 segment, we only use the RTT
// sample from the highest snum.

               if ((last_ack_ >= 0) && ((nextTimedSeqno == 0) || (tcph->seqno() >= nextTimedSeqno))) {
                  nextTimedSeqno = 0;
                  tcpRTT = Scheduler::instance().clock() -
                         tcpSendTime[last_ack_ % maxcwnd_];
                  FinalRTT_ += tcpRTT;
                  FinalLossRTTMeanCounter_ +=1;
#ifdef TCPRENO
                  if (cx_id_ == TRACED_CX) {
                    printf("TCPReno:recv(%g):SAMPLING: Ack of %d arrived. sendTime= %g, maxseq=%d,lastack=%d ,nextTimedSe=%d, tcpRTT:%g, pktts:%g\n",
                       Scheduler::instance().clock(), tcph->seqno(),
                        tcpSendTime[last_ack_ % maxcwnd_],(int)maxseq_,last_ack_,nextTimedSeqno, (double) tcpRTT,(double)tcph->ts());
                  }
#endif
                }
                else {
                  // else this is a dup ack ...
                  // set tcpRTT to indicate a dup arrived.
#ifndef TRACERETRANS
                  tcpRTT = 0;
#endif
#ifdef TCPRENO
                  if (cx_id_ == TRACED_CX) {
                      printf("TCPReno:recv(%g):NO SAMPLING: Ack of %d arrived. lastack=%d,netTimedSeqno=%d \n",
                                Scheduler::instance().clock(),tcph->seqno(), last_ack_,nextTimedSeqno);
                  }
#endif
               }



	} else if (tcph->seqno() == last_ack_) {
		if (hdr_flags::access(pkt)->eln_ && eln_) {
			tcp_eln(pkt);
			return;
		}
		if (++dupacks_ == numdupacks_) {
			dupack_action();
			if (!exitFastRetrans_)
				dupwnd_ = numdupacks_;
		} else if (dupacks_ > numdupacks_ && (!exitFastRetrans_ 
		     || last_cwnd_action_ == CWND_ACTION_DUPACK )) {
			++dupwnd_;	// fast recovery
		} else if (dupacks_ < numdupacks_ && singledup_ ) {
			send_one();
		}

//JJM
#ifndef TRACERETRANS
                tcpRTT = 0;
                trace(&tcpRTT);
#endif



                if (nextTimedSeqno > 0)
                    nextTimedSeqno = (int)maxseq_ + 1;
                if (nextTimedSeqno == 0)
                    nextTimedSeqno = (int)maxseq_ + 1;
#ifdef TCPRENO
       if (cx_id_ == TRACED_CX)
                printf("TCPReno:recv(%g): Dup Ack of %d arrived. dupacks now %d,nextTimedSeqno=%d \n",
                     Scheduler::instance().clock(), tcph->seqno(),(int)dupacks_,nextTimedSeqno);
#endif




	}
        if (tcph->seqno() >= last_ack_)
                // Check if ACK is valid.  Suggestion by Mark Allman.
                valid_ack = 1;
	Packet::free(pkt);
#ifdef notyet
	if (trace_)
		plot();
#endif

	/*
	 * Try to send more data
	 */

        if (valid_ack || aggressive_maxburst_)
          if (dupacks_ == 0 || dupacks_ > numdupacks_ - 1)
          {
			send_much(0, 0, maxburst_);

//$A304
#ifdef TCPRENO
             if (cx_id_ == TRACED_CX)
                    printf("TCPReno:recv(%g): highest_ack_:%d,  maxseq_ : %d\n",
                         Scheduler::instance().clock(), int(highest_ack_),int(maxseq_));
#endif
#ifdef TRACEBURST
        if (cx_id_ == TRACED_BURST_CX) {
          if (highest_ack_ == maxseq_) {
//            printf("\n2 %f", Scheduler::instance().clock());
            FILE* fp = fopen("wrt.out", "a+");
            fprintf(fp,"\n2 %f", Scheduler::instance().clock());
            fclose(fp);

             globalBurstFlag = 0;
#ifdef TCPRENO
             if (cx_id_ == TRACED_CX)
                printf("TCPReno:recv(%g): end of burst ,  reset globalBurstFlag ,  cwnd_ : %f\n",
                     Scheduler::instance().clock(), double(cwnd_));
#endif
          }
        }
#endif

          }
}

int
RenoTcpAgent::allow_fast_retransmit(int last_cwnd_action_)
{
	return (last_cwnd_action_ == CWND_ACTION_DUPACK);
}

/*
 * Dupack-action: what to do on a DUP ACK.  After the initial check
 * of 'recover' below, this function implements the following truth
 * table:
 *  
 *      bugfix  ecn     last-cwnd == ecn        action  
 *  
 *      0       0       0                       reno_action
 *      0       0       1                       reno_action    [impossible]
 *      0       1       0                       reno_action
 *      0       1       1                       retransmit, return  
 *      1       0       0                       nothing 
 *      1       0       1                       nothing        [impossible]
 *      1       1       0                       nothing 
 *      1       1       1                       retransmit, return
 */ 
    
void
RenoTcpAgent::dupack_action()
{
	int recovered = (highest_ack_ > recover_);
	int allowFastRetransmit = allow_fast_retransmit(last_cwnd_action_);
        if (recovered || (!bug_fix_ && !ecn_) || allowFastRetransmit 
		|| (bugfix_ss_ && highest_ack_ == 0)) {
                // (highest_ack_ == 0) added to allow Fast Retransmit
                //  when the first data packet is dropped.
                //  From bugreport from Mark Allman.
		goto reno_action;
	}

	if (ecn_ && last_cwnd_action_ == CWND_ACTION_ECN) {
		last_cwnd_action_ = CWND_ACTION_DUPACK;
		/* 
		 * What if there is a DUPACK action followed closely by ECN
		 * followed closely by a DUPACK action?
		 * The optimal thing to do would be to remember all
		 * congestion actions from the most recent window
		 * of data.  Otherwise "bugfix" might not prevent
		 * all unnecessary Fast Retransmits.
		 */
		reset_rtx_timer(1,0);
		output(last_ack_ + 1, TCP_REASON_DUPACK);
		dupwnd_ = numdupacks_;
		return; 
	}

	if (bug_fix_) {
		/*
		 * The line below, for "bug_fix_" true, avoids
		 * problems with multiple fast retransmits in one
		 * window of data.
		 */
		return;
	}

reno_action:
	// we are now going to fast-retransmit and will trace that event
	trace_event("RENO_FAST_RETX");
	recover_ = maxseq_;
	last_cwnd_action_ = CWND_ACTION_DUPACK;
	slowdown(CLOSE_SSTHRESH_HALF|CLOSE_CWND_HALF);
	reset_rtx_timer(1,0);
	output(last_ack_ + 1, TCP_REASON_DUPACK);	// from top
        dupwnd_ = numdupacks_;
	return;
}

void RenoTcpAgent::timeout(int tno)
{

//$A304
#ifdef TCPRENO
        if (cx_id_ == TRACED_CX) {
          printf("TCPReno:timeout(%g): reno timeout called with tno of %d \n",
                   Scheduler::instance().clock(),tno);
        }
#endif

	if (tno == TCP_TIMER_RTX) {
		dupwnd_ = 0;
		dupacks_ = 0;
		if (bug_fix_) recover_ = maxseq_;
		TcpAgent::timeout(tno);
	} else {
//$A304
//		timeout_nonrtx(tno);
          if (HIGHSPEED == 0) {
                timeout_nonrtx(tno);
           }
	}
}
