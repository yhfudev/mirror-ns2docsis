//for the phy, channel channel-mux, channelPktQ

//#define ALL_DEBUG 1

#ifdef ALL_DEBUG
#define TRACEME 0

//For mac-docsisbase.cc
#define TRACE 0

#define TRACE_CMTS 0

//For mac-docsis-state-machine.cc
#define TRACEME 0

//udp-sink.cc
#define TRACEUDPSINK 0

//tcp-sink
#define TRACESINK 1

//tcp.cc
#define TRACETCP 0
#define TRACERENO 0
#define TRACENEWRENO 0


#endif


