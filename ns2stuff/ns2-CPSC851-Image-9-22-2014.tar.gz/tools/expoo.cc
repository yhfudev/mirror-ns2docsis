/* -*-	Mode:C++; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */
/*
 * Copyright (c) Xerox Corporation 1997. All rights reserved.
 *  
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation; either version 2 of the License, or (at your
 * option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * Linking this file statically or dynamically with other modules is making
 * a combined work based on this file.  Thus, the terms and conditions of
 * the GNU General Public License cover the whole combination.
 *
 * In addition, as a special exception, the copyright holders of this file
 * give you permission to combine this file with free software programs or
 * libraries that are released under the GNU LGPL and with code included in
 * the standard release of ns-2 under the Apache 2.0 license or under
 * otherwise-compatible licenses with advertising requirements (or modified
 * versions of such code, with unchanged license).  You may copy and
 * distribute such a system following the terms of the GNU GPL for this
 * file and the licenses of the other code concerned, provided that you
 * include the source code of that other code when and as the GNU GPL
 * requires distribution of source code.
 *
 * Note that people who make modified versions of this file are not
 * obligated to grant this special exception for their modified versions;
 * it is their choice whether to do so.  The GNU General Public License
 * gives permission to release a modified version without this exception;
 * this exception also makes it possible to release a modified version
 * which carries forward this exception.
 */

#ifndef lint
static const char rcsid[] =
    "@(#) $Header: /cvsroot/nsnam/ns-2/tools/expoo.cc,v 1.15 2005/08/26 05:05:30 tomh Exp $ (Xerox)";
#endif

#include <stdlib.h>
 
#include "random.h"
#include "trafgen.h"
#include "ranvar.h"


//$A304
/*To trace this module uncomment this ..*/
//note,  only traces if mode_ set to 1 or 2
#include "../mac/docsis/docsisDebug.h"
//#define TRACEEXPOO 0
// traces all
//#define TRACEALL 0
//To do on/off instead of exp,
//$A10 2-24-2013 support mode
//mode 0: 
//mode 1:
#define DOONOFF 0
// a number of packets to burst
//Used to be 7
// burt size of 34 : 49640 bytes
//burst size of 13 : 18980
//#define BURSTSIZE 13
// ORG #define BURSTSIZE 13
//
// Number bytes=  64K
// 128K
// 256
// 512
// 1024K = 1500 * x      x = 683
#define BURSTSIZE 13

// A static idle time in seconds
//#define IDLETIME 20
#define IDLETIME 1
//See tcp-reno.cc which records when the final ack from the burst arrives
#define TRACEBURST 0
//If 1, then we are in the middle of a burst...
int globalBurstFlag = 0;

//$A0 add
//comment this out to eliminate... note this significantly changes the avg bw consumed ...
#define MAXBURSTSIZE 5


//Set the mode in tcl via 
//mode_ behavior
// 0:   no changes
// 1 :  turns the exp gen into CBR where it bursts BURSTSIZE each interval
// 2 :  only change is to limit the max burst size to MAXBURSTSIZE packets
// 3:   similar to 1, excepta it uses the tcl params- just removes the use
//          of an exponential RV to generate the next burst size and idle time.
//           The next rem_ is 


/* implement an on/off source with exponentially distributed on and
 * off times.  parameterized by average burst time, average idle time,
 * burst rate and packet size.
 */

class EXPOO_Traffic : public TrafficGenerator {
 public:
	EXPOO_Traffic();
	virtual double next_interval(int&);
        virtual void timeout();
	// Added by Debojyoti Dutta October 12th 2000
	int command(int argc, const char*const* argv);
 protected:
	void init();
	double ontime_;   /* average length of burst (sec) */
	double offtime_;  /* average length of idle time (sec) */
	double rate_;     /* send rate during on time (bps) */
	double interval_; /* packet inter-arrival time during burst (sec) */
	unsigned int rem_; /* number of packets left in current burst */

//$A304
        int mode_;     /* sets mode: normal(0) or special TCP web burst application (1)*/
                      // or a value of 2 turns on the MAX burst mode where we limit the number of segs
                      // sent in a burst
        int fixed_burst_;     /* for mode_ > 0, this is the fixed burst size*/
//$A10
        double fixed_offtime_;    /* for mode_ 3, this is fixed off time

//$A304

	/* new stuff using RandomVariable */
	ExponentialRandomVariable burstlen_;
	ExponentialRandomVariable Offtime_;

};


static class EXPTrafficClass : public TclClass {
 public:
	EXPTrafficClass() : TclClass("Application/Traffic/Exponential") {}
	TclObject* create(int, const char*const*) {
		return (new EXPOO_Traffic());
	}
} class_expoo_traffic;

// Added by Debojyoti Dutta October 12th 2000
// This is a new command that allows us to use 
// our own RNG object for random number generation
// when generating application traffic

int EXPOO_Traffic::command(int argc, const char*const* argv){
        
        if(argc==3){
                if (strcmp(argv[1], "use-rng") == 0) {
                        burstlen_.seed((char *)argv[2]);
                        Offtime_.seed((char *)argv[2]);
                        return (TCL_OK);
                }
//$A304
                if (strcmp(argv[1], "setRate") == 0) {
                        rate_ = (double)atof(argv[2]);
                        rem_ = 0;
                        if (rate_ >0) {
                          interval_ = (double)(size_ << 3)/(double)rate_;
                          burstlen_.setavg(ontime_/interval_);
                        }
#ifdef TRACEALL
                        printf("EXPOO_Traffic::cmd(%f): set rate to %f \n",
                                  Scheduler::instance().clock(), rate_);
#endif
                        return (TCL_OK);
                }
//$A304
        }
        return Application::command(argc,argv);
}


EXPOO_Traffic::EXPOO_Traffic() : burstlen_(0.0), Offtime_(0.0)
{
	bind_time("burst_time_", &ontime_);
//$A10
	bind_time("idle_time_", Offtime_.avgp());
//	bind_time("idle_time_", &offtime_);
//    Offtime_.setavg(offtime_);

	bind_bw("rate_", &rate_);
	bind("packetSize_", &size_);

//$A304
//$A10
        fixed_burst_ = 0;  
        fixed_offtime_ = 0.0;  
        bind("mode_", &mode_);
        bind("fixed_burst_", &fixed_burst_);

}

void EXPOO_Traffic::init()
{
        /* compute inter-packet interval during bursts based on
	 * packet size and burst rate.  then compute average number
	 * of packets in a burst.
	 */
	interval_ = (double)(size_ << 3)/(double)rate_;
	burstlen_.setavg(ontime_/interval_);
	rem_ = 0;
    if (mode_ == 3) {
      fixed_burst_ = (int) (ontime_/interval_);
      fixed_offtime_ = *(Offtime_.avgp());
    }
//$A304
//      if (agent_)
//              agent_->set_pkttype(PT_EXP);
#ifdef TRACEALL
    printf("EXPOO_Traffic::next(%f): inited an EXP generator, with mode: %d, and avg burstlen %f (rate_:%lf, interval_:%lf,ontime_:%lf)\n",
         Scheduler::instance().clock(), mode_,ontime_/interval_,rate_,interval_,ontime_);
    if (mode_ == 3) {
      printf("EXPOO_Traffic::Init(%f): mode 3: fixed_burst_:%d, fixed_offtime_:%f)\n",
         Scheduler::instance().clock(), fixed_burst_,fixed_offtime_);
    }
#endif
  if (mode_ == 3) {
    printf("EXPOO_Traffic::init(%f): EXP MODE 3: fixed_burst_:%d, fixed_offtime_:%f, rate: %9.0f)\n",
        Scheduler::instance().clock(), fixed_burst_,fixed_offtime_, (fixed_burst_*size_*8)/fixed_offtime_);
  }

}

double EXPOO_Traffic::next_interval(int& size)
{
	double t = interval_;

	if (rem_ == 0) {
		/* compute number of packets in next burst */
		rem_ = int(burstlen_.value() + .5);
		/* make sure we got at least 1 */
		if (rem_ == 0)
			rem_ = 1;
		/* start of an idle period, compute idle time */
		t += Offtime_.value();

//$A304
        if (mode_ == 2)
        {
          if ((MAXBURSTSIZE > 0) && (rem_ > MAXBURSTSIZE)) {
            rem_ = MAXBURSTSIZE;
#ifdef TRACEEXPOO
            printf("EXPOO_Traffic::next(%f): reduced next burst to %d \n",
                     Scheduler::instance().clock(), rem_);
#endif
            }
       }
       if (mode_ == 1)
       {
         rem_ = BURSTSIZE;
         t = interval_  + IDLETIME;
       }
       if (mode_ == 3) {
         rem_ = fixed_burst_;
         t = interval_  + fixed_offtime_;
       }
#ifdef TRACEEXPOO
       if (mode_ == 1)
         printf("EXPOO_Traffic::next(%f): new rem is %d, interval is %f\n",
                    Scheduler::instance().clock(), rem_,t);
#endif
#ifdef TRACEALL
       printf("EXPOO_Traffic::next(%f): new rem is %d, interval is %f \n",
               Scheduler::instance().clock(), rem_,t);
#endif
//$A304
    }	

	rem_--;

	size = size_;
	return(t);
}

void EXPOO_Traffic::timeout()
{

//$A304
int burstActiveFlag = 0;
FILE* fp;

#ifdef TRACEEXPOO
        if (mode_ == 1)
            printf("XPOO_Traffic::timeout(%f): globalBurstFlag = %d \n",
                     Scheduler::instance().clock(), globalBurstFlag);
#endif


	if (! running_)
		return;

#ifdef TRACEBURST
       if (mode_ == 1) {
        if  (rem_ == (BURSTSIZE-1)) {
          if (globalBurstFlag == 0) {
            globalBurstFlag = 1;
//            printf("\n1 %f", Scheduler::instance().clock());
//            fp = fopen("snumack.out", "a+");
            fp = fopen("wrt.out", "a+");
            fprintf(fp,"\n1 %f", Scheduler::instance().clock());
            fclose(fp);
          }
         else {
            burstActiveFlag = 1;
         }
        }
      }
#endif

      if (burstActiveFlag == 0) {

#ifdef TRACEEXPOO
         if (mode_ == 1)
          printf("EXPOO_Traffic::timeout(%f): send msg size %d (rem=%d)\n",
                     Scheduler::instance().clock(),size_,rem_);
#endif
#ifdef TRACEALL
//          printf("EXPOO_Traffic::timeout(%f): send msg size %d (rem=%d)\n",
//                     Scheduler::instance().clock(),size_,rem_);
#endif

	/* send a packet */
	// The test tcl/ex/test-rcvr.tcl relies on the "NEW_BURST" flag being 
	// set at the start of any exponential burst ("talkspurt").  
	if (nextPkttime_ != interval_ || nextPkttime_ == -1) 
		agent_->sendmsg(size_, "NEW_BURST");
	else 
		agent_->sendmsg(size_);
	/* figure out when to send the next one */
	nextPkttime_ = next_interval(size_);
	/* schedule it */
	if (nextPkttime_ > 0)
		timer_.resched(nextPkttime_);
}
//$A304
       else {
//We need to initiate a new burst in 4 seconds....
          rem_ = 0;
          nextPkttime_ = next_interval(size_);
          //override with a large interval
          nextPkttime_ = 4;
          timer_.resched(nextPkttime_);
#if (TRACEBURST && TRACEEXPO)
          printf("EXPOO_Traffic::timeout(%f): Burst time but not done with previous... (size_\%d; rem_=%d) \n",
                     Scheduler::instance().clock(),size_,rem_);
#endif
        }

}


