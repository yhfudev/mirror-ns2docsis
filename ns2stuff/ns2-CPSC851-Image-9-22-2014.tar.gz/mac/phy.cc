/* -*-	Mode:C++; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */
/*
 * Copyright (c) 1997 Regents of the University of California.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *	This product includes software developed by the Computer Systems
 *	Engineering Group at Lawrence Berkeley Laboratory.
 * 4. Neither the name of the University nor of the Laboratory may be used
 *    to endorse or promote products derived from this software without
 *    specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *

 * @(#) $Header: 

 *
 * Ported from CMU/Monarch's code, nov'98 -Padma Haldar.
 * phy.cc
 */

#include <math.h>

#include "config.h"
#include <packet.h>
#include <phy.h>
#include <dsr/hdr_sr.h>
//
//uncomment for printf's
#include <rtp.h>

#include "./docsis/mac-docsis.h"
#include "../mac/docsis/docsisDebug.h"
//#define TRACEME 0

class Mac;

static int InterfaceIndex = 0;


Phy::Phy() : BiConnector() {
	index_ = InterfaceIndex++;
	bandwidth_ = 0.0;
	channel_ = 0;
	node_ = 0;
	head_ = 0;

//$A300
        pktQSize_ = 0;
        for (int i = 0; i < 10; i++)
           pktQ[i] = NULL;

}

int
Phy::command(int argc, const char*const* argv) {
	if (argc == 2) {
		Tcl& tcl = Tcl::instance();

		if(strcmp(argv[1], "id") == 0) {
			tcl.resultf("%d", index_);
			return TCL_OK;
		}
	}

	else if(argc == 3) {

		TclObject *obj;

		if (strcmp(argv[1], "setupchan") == 0) {
	                setupchan(atoi(argv[2]));
		        return TCL_OK;
		}
		if( (obj = TclObject::lookup(argv[2])) == 0) {
			fprintf(stderr, "%s lookup failed\n", argv[1]);
			return TCL_ERROR;
		}
		if (strcmp(argv[1], "channel") == 0) {
                        assert(channel_ == 0);
			channel_ = (Channel*) obj;
			downtarget_ = (NsObject*) obj;
			// LIST_INSERT_HEAD() is done by Channel
			return TCL_OK;
		}
		else if (strcmp(argv[1], "node") == 0) {
			assert(node_ == 0);
			node_ = (Node*) obj;
			// LIST_INSERT_HEAD() is done by Node
			return TCL_OK;
		}
		else if (strcmp(argv[1], "linkhead") == 0) {
			head_ = (LinkHead*)  obj;
			return (TCL_OK);
		}

	} 
	return BiConnector::command(argc, argv);
}

/*void Phy::recv(Packet* p , Handler* h,int channelID)
{
	thisChannelID = channelID;
	recv(p,h);
}*/

void
Phy::recv(Packet* p, Handler*)
{
	struct hdr_cmn *hdr = HDR_CMN(p);	
	//struct hdr_sr *hsr = HDR_SR(p);
//$A300
  // struct hdr_docsis* dh = HDR_DOCSIS(p);
  struct hdr_mac *mh = HDR_MAC(p);
  //docsis_chabstr *ch_abs = docsis_chabstr::access(p);    
	
	/*
	 * Handle outgoing packets
	 */
	switch(hdr->direction()) {
	case hdr_cmn::DOWN :
		/*
		 * The MAC schedules its own EOT event so we just
		 * ignore the handler here.  It's only purpose
		 * it distinguishing between incoming and outgoing
		 * packets.
		 */
#ifdef TRACEME
  printf("phy:recv(%lf): send it down \n", Scheduler::instance().clock());
#endif

		sendDown(p);
		return;
	case hdr_cmn::UP :
#ifdef TRACEME
  printf("phy:recv(%lf): send it up \n", Scheduler::instance().clock());
#endif
		if (sendUp(p) == 0) {
			/*
			 * XXX - This packet, even though not detected,
			 * contributes to the Noise floor and hence
			 * may affect the reception of other packets.
			 */
#ifdef TRACEME
  printf("phy:recv(%lf): ERROR sendUp returned a 0 ??? \n", Scheduler::instance().clock());
#endif
			Packet::free(p);
			return;
		} else {
#ifdef TRACEME
  printf("phy:recv(%lf): move to uptarget->revc size:%d) mac SA:%d, DA:%d\n", 
	 Scheduler::instance().clock(),hdr->size(), mh->macSA(),mh->macDA());
#endif
			uptarget_->recv(p, (Handler*) 0);
		}
		break;
	default:
#ifdef TRACEME
		printf("Direction for pkt-flow not specified; Sending pkt up the stack on default.\n\n");
#endif
		if (sendUp(p) == 0) {
			/*
			 * XXX - This packet, even though not detected,
			 * contributes to the Noise floor and hence
			 * may affect the reception of other packets.
			 */
			Packet::free(p);
			return;
		} else {
			uptarget_->recv(p, (Handler*) 0);
		}
	}
	
}


// double
// Phy::txtime(Packet *p) const
// {
// 	hdr_cmn *hdr = HDR_CMN(p);
// 	return hdr->size() * 8.0 / Rb_;
// }


void
Phy::dump(void) const
{
	fprintf(stdout, "\tINDEX: %d\n",
		index_);
	fprintf(stdout, "\tuptarget: %x, channel: %x",
		(u_int32_t) uptarget_, (u_int32_t) channel_);

}


//Biswajit
int Phy::linkchan(void)
{
        int i;
        for (i=0; i < numChannel; i++)
        {
               /*if(channel_[i] == NULL)
               return i;*/
	}
        return -1;
}
//Biswajit
void Phy::setupchan(int numChan)
{
	int i;
	numChannel = numChan;
	lastpkt =0;
}

int Phy::pktQSize(void)
{
  return(pktQSize_);
}

//Rmove from queue, don't free
void Phy::removeLastPkt()
{

if (pktQSize_ >0) {
  lastpkt--;
  pktQSize_--;
#ifdef TRACEME
  printf("Phy::removeLastPkt(%lf): new PktQSize:%d!!\n", Scheduler::instance().clock(),pktQSize_);
#endif
}
#ifdef TRACEME
else
  printf("Phy::removeLastPkt(%lf): Could not, queue empty:%d!!\n", Scheduler::instance().clock(),pktQSize_);
#endif
}


void Phy::insertpkt(Packet *p)
{
  struct hdr_cmn* ch = HDR_CMN(p);        /* Common header part */
  hdr_tcp *tcph = hdr_tcp::access(p);
  hdr_rtp* rh = hdr_rtp::access(p);


#ifdef TRACEME
 if (ch->direction() == hdr_cmn::UP)
  printf("Phy::insertpkt(%lf): Going Upstream, before insert, current PktQSize:%d!!\n", Scheduler::instance().clock(),pktQSize_);
 else
  printf("Phy::insertpkt(%lf): Going Downstream, before insert, current PktQSize:%d!!\n", Scheduler::instance().clock(),pktQSize_);
#endif
  if (pktQSize_ >= maxpktQSize) {
    printf("Phy::insertpkt(%lf): ERROR:  exceeding maxPktQSize!!\n", Scheduler::instance().clock());
    exit(1);
  }
  //Traverse thru the Q to find the first empty packet
#ifdef TRACEME
  if(ch->ptype_ == PT_TCP) 
    printf("Phy::insertpkt(%lf): TCP packet Sequence Num %d Ack No   %d\n",
         Scheduler::instance().clock(),tcph->seqno(), tcph->ackno());
  if(ch->ptype_ == PT_UDP) 
    printf("Phy::insertpkt(%lf): UDP packet Sequence Num %d \n",
         Scheduler::instance().clock(),rh->seqno());

  fflush(stdout);
#endif
	pktQ[lastpkt] = p;
	//printf("Phy::insertpkt %d PacketQ %x\n",lastpkt,this->pktQ[lastpkt]);
	lastpkt++;
        pktQSize_++;
}

Packet * Phy::getnextpkt(void)
{
  Packet *p = NULL;

  if (pktQSize_ > 0)
    p = pktQ[0]->copy();

  return p;
}

//TODO:  change this to dequeue, don't have anyone access the pktQ except the insert/dequeue methods
void Phy::consumepkt(void)
{
  Packet *p = pktQ[0];
  struct hdr_cmn* ch = HDR_CMN(p);        /* Common header part */
  hdr_tcp *tcph = hdr_tcp::access(p);
  hdr_rtp* rh = hdr_rtp::access(p);
  int i;

  if (pktQSize_ <= 0) {
    printf("Phy::consumepkt(%lf): ERROR: no packets on the queue \n",
         Scheduler::instance().clock());
    return;
  }
  //Traverse thru the Q to find the first empty packet
#ifdef TRACEME
  if(ch->ptype_ == PT_TCP) 
    printf("Phy::consumepkt(%lf): TCP packet Sequence Num %d Ack No   %d\n",
         Scheduler::instance().clock(),tcph->seqno(), tcph->ackno());
  if(ch->ptype_ == PT_UDP) 
    printf("Phy::consumepkt(%lf): UDP packet Sequence Num %d \n",
         Scheduler::instance().clock(),rh->seqno());

  fflush(stdout);
#endif

	for(i=0; i <  lastpkt; i++)
	{
		pktQ[i] = pktQ[i+1];
	}	
	lastpkt--;
        pktQSize_--;
	
}

Packet *Phy::dequeuepkt(void)
{
  Packet *p = pktQ[0];
  struct hdr_cmn* ch = HDR_CMN(p);        /* Common header part */
  hdr_tcp *tcph = hdr_tcp::access(p);
  hdr_rtp* rh = hdr_rtp::access(p);
  int i;

  if (pktQSize_ <= 0) {
    printf("Phy::consumpkt(%lf): ERROR: no packets on the queue \n",
         Scheduler::instance().clock());
    return(NULL);
  }
  //Traverse thru the Q to find the first empty packet
#ifdef TRACEME
  if(ch->ptype_ == PT_TCP) 
    printf("Phy::dequeuepkt(%lf): TCP packet Sequence Num %d Ack No   %d\n",
         Scheduler::instance().clock(),tcph->seqno(), tcph->ackno());
  else
    printf("Phy::consumepkt(%lf): UDP packet Sequence Num %d \n",
         Scheduler::instance().clock(),rh->seqno());

  fflush(stdout);
#endif

	for(i=0; i <  lastpkt; i++)
	{
		pktQ[i] = pktQ[i+1];
	}	
	lastpkt--;
        pktQSize_--;
	
  return p;
}

