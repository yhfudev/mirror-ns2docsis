#ifndef ns_mac_docsisVersion_h
#define ns_mac_docsisVersion_h

#define docsisModelVersion .993

#endif /* __mac_docsisVersion_h__ */

